import sqlite3

import module_14_4
from Homeworks.module_14_4 import *


def initiate_db():
    connection = sqlite3.Connection("database.db")
    cursor = connection.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Products(
    id INT NOT NULL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price INT NOT NULL
    );
    ''')

    connection.commit()
    connection.close()


def get_all_products():
    connection = sqlite3.connect("database.db")
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM Products')
    rows = cursor.fetchall()
    column_names = [description[0] for description in cursor.description]
    products = [dict(zip(column_names, row)) for row in rows]
    connection.close()
    return products


if __name__ == "__main__":
    initiate_db()
    all_products = get_all_products()
    for product in all_products:
        print(product)

# connection = sqlite3.Connection("database.db")
# cursor = connection.cursor()
# for i in range(1,5):
#     cursor.execute("INSERT INTO Products (id, title, description, price) VALUES (?, ?, ?, ?)", (i, f"Банка {i}", f"{i} вариант продукта", f"{1000*i}"))

# connection.commit()
# connection.close()